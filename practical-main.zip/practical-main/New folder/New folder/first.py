# Define the grammar rules
grammar = {
    "S": ["ABC", "BCD", "BD", "CE"],
    "A": ["a"],
    "B": ["b", "epsilon"],
    "C": ["c"],
    "D": ["d", "epsilon"],
    "E": ["e", "epsilon"]
}


# Define the FIRST set function
def FIRST(NT):
    # Check if this is a terminal symbol
    if NT not in grammar:
        return {NT}
    
    # Otherwise, initialize the FIRST set to be empty
    first_set = set()
    
    # Iterate through each production rule for the non-terminal symbol
    for production in grammar[NT]:
        # Check if the first character of the production rule is a terminal symbol
        if production[0] not in grammar:
            first_set.add(production[0])
        # Otherwise, add all the elements of the FIRST set of the non-terminal symbol
        else:
            for symbol in FIRST(production[0]):
                first_set.add(symbol)
    
        # Check if the production rule can derive epsilon
        if 'epsilon' in production:
            # If so, add the elements of the FIRST set of the next symbol in the rule
            for symbol in FIRST(production[1:]):
                first_set.add(symbol)
    
    return first_set

print("FIRST(S) = ", FIRST('S'))
print("FIRST(A) = ", FIRST('A'))
print("FIRST(B) = ", FIRST('B'))
print("FIRST(C) = ", FIRST('C'))
print("FIRST(D) = ", FIRST('D'))
print("FIRST(E) = ", FIRST('E'))