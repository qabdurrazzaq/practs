import string

n, m, p, i, j = 0, 0, 0, 0, 0
a = [[] for _ in range(10)]
f = [''] * 10

def follow(c):
    global m, i, j
    if a[0][0] == c:
        f[m] = '$'
        m += 1
    for i in range(n):
        for j in range(2, len(a[i])):
            if a[i][j] == c:
                if a[i][j] != None:
                    first(a[i][j])
                if a[i][j] == None and c != a[i][0]:
                    follow(a[i][0])

def first(c):
    global m, i, j
    if not c.isupper():
        f[m] = c
        m += 1
    for k in range(n):
        if a[k][0] == c:
            if a[k][2] == '$':
                follow(a[i][0])
            elif a[k][2].islower():
                f[m] = a[k][2]
                m += 1
            else:
                first(a[k][2])

print("Enter the no.of productions : ", end="")
n = int(input())
print("Enter the productions (epsilon = $):")
for i in range(n):
    a[i] = input().strip()

while True:
    m = 1
    c = input("Char : ")
    follow(c)
    print(f" ===> FOLLOW({c}) = {{ {' '.join(f[:m])} }}")
    choice = input("0.Exit  1.Continue : ")
    if choice != "1":
        break


'''
/*Enter the no.of productions : 8
Enter the productions(epsilon=$):

E=TD
D=+TD
D=$
T=FS
S=*FS
S=$
F=(E)
F=a

Char :E
 ===> FOLLOW(E) = { $ )  }
0.Exit  1.Continue : 1

Char :S
 ===> FOLLOW(S) = { + $ )  }
0.Exit  1.Continue : 1

Char :F
 ===> FOLLOW(F) = { * + $ )  }
0.Exit  1.Continue : 1

Char :T
 ===> FOLLOW(T) = { + $ )  }
0.Exit  1.Continue : 0

*/

'''
