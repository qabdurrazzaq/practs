# Python equivalent code for the given C code

import string

count = int(input("How many productions ? : "))
prodn = [input("Enter production {}: ".format(i+1)) for i in range(count)]
first = []

def FIRST(c):
    global n
    if c not in string.ascii_uppercase:
        first.append(c)
        n += 1
    for j in range(count):
        if prodn[j][0] == c:
            if prodn[j][2] == '$':
                first.append('$')
                n += 1
            elif prodn[j][2] in string.ascii_lowercase:
                first.append(prodn[j][2])
                n += 1
            else:
                FIRST(prodn[j][2])

while True:
    n = 0
    c = input("\nElement : ")
    FIRST(c)
    print("===> FIRST({})= {{ {} }}".format(c, ' '.join(first)))
    first.clear()
    choice = input("press 1 to continue : ")
    if choice != '1':
        break
'''
/*How many productions ? :8
Enter 8 productions epsilon= $ :

E=TD
D=+TD
D=$
T=FS
S=*FS
S=$
F=(E)
F=a

Element :E
===>  FIRST(E)= { ( a }
press 1 to continue : 1

Element :D
===> FIRST(D)= { + $ }
press 1 to continue : 1

Element :T
===> FIRST(T)= { ( a }
press 1 to continue : 0

*/
'''
