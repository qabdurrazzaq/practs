class DefTab:
    def __init__(self, opcode, operand):
        self.opcode = opcode
        self.operand = operand

class NamTab:
    def __init__(self, name, start, end):
        self.name = name
        self.start = start
        self.end = end

class ArgTab:
    def __init__(self, arg):
        self.arg = arg

class ParamTab:
    def __init__(self, param, val):
        self.param = param
        self.val = val

def check_param(x, pt, p):
    for i in range(p):
        if pt[i].param == x:
            return i
    return -1

def check_macro(x, nt, m):
    for i in range(m):
        if nt[i].name == x:
            return i
    return -1

def store():
    n = p = m = g = 0
    dt = []
    nt = []
    at = []
    pt = []
    with open("in10.txt", "r") as f, open("exp.txt", "w") as fp:
        k = 0
        for line in f:
            a, b, c = line.strip().split("\t")
            if b == "MACRO":
                nt.append(NamTab(a, 0, 0))
                m += 1
                k = 1
                i = j = 0
                while i < len(c):
                    if c[i] != ",":
                        temp = c[i]
                        j += 1
                    else:
                        temp = ""
                        j = 0
                        pt.append(ParamTab("", ""))
                        pt[p].param = temp
                        pt[p].val = "?" + str(p+1)
                        p += 1
                    i += 1
                temp = c[i-1]
                pt.append(ParamTab("", ""))
                pt[p].param = temp
                pt[p].val = "?" + str(p+1)
                p += 1
                dt.append(DefTab(b, c))
                n += 1
            elif k == 1:
                i = check_param(c, pt, p)
                dt.append(DefTab(b, c if i == -1 else pt[i].val))
                n += 1
                if b == "MEND":
                    k = 0
                    nt[m-1].end = n-1
            elif check_macro(b, nt, m) != -1:
                i = 0
                g = 0
                j = 0
                while i < len(c):
                    if c[i] != ",":
                        temp = c[i]
                        j += 1
                    else:
                        temp = ""
                        j = 0
                        at.append(ArgTab(""))
                        at[g].arg = temp
                        g += 1
                    i += 1
                temp = c[i-1]
                at.append(ArgTab(""))
                at[g].arg = temp
                g += 1
                a = "NULL"
                for i in range(1, n-1):
                    if dt[i].operand[0] == "?":
                        j = int(dt[i].operand[1]) - 1
                        temp = at[j].arg
                    else:
                        temp = dt[i].operand
                fp.write(f"{a}\t{dt[i].opcode}\t{temp}\n")
                a = "NULL"

    print("\n DEFTAB:\n")
    for i in range(n):
        print(dt[i].opcode + "\t" + dt[i].operand)

    print("\n NAMETAB:\n NAME\tSTART\tEND")
    for i in range(m):
        print(nt[i].name + "\t" + str(nt[i].start) + "\t" + str(nt[i].end))

    print("\n ARGTAB \n Position\tArgument")
    for i in range(g):
        print(str(i+1) + "\t" + at[i].arg)

def write_to_file(string_to_write):
    with open('exp.txt', 'w') as file:
        file.write(string_to_write)

string_to_write = "MOV A,&X\nADD A,&Y\nMOV A,&Z\nADD A,&W\nMOV A,&Y\nADD A,&W\nADD &X,&Y\nADD &Z,&W\nADD &Y,&W\n"
write_to_file(string_to_write)
